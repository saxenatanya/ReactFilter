import logo from './logo.svg';
import './App.css';
import First from "./components/First";

function App() {
  return (
    <div className="App">
      
      <First name="User Data"/>
     
    </div>
  );
}

export default App;
